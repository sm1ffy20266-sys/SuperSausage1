# Super Sausage Auto v2.0

Android automation project for the user's Z Route: Redemption Radiated Elite mission workflow.

## What changed in v2

- Uses Android AccessibilityService screenshot capture on Android 11+.
- Uses ML Kit on-device text recognition to identify visible labels.
- Taps the centre of recognised labels rather than relying only on fixed 720x1600 coordinates.
- Stops on purchase/payment-related text or unknown/ambiguous screens.
- Maximum 25 cycles per run.
- Minimum 1.8 second gap between automated taps and about 2.2 seconds between recognition passes.

Android's AccessibilityService supports retrieving active-window content and, on Android 11+, taking display screenshots; gesture dispatch requires the service's gesture capability. See the official Android API documentation.

## Build

Open this folder in Android Studio with an internet connection so Gradle can resolve the Android and ML Kit dependencies.

Requirements:
- Android Studio with SDK 35 installed.
- JDK 17 (recommended for current Android Gradle Plugin versions).
- Android 11+ on the phone for screenshot/OCR recognition.

Then use **Build > Build APK(s)**.

## Install/use

1. Install the generated APK.
2. Open Super Sausage Auto.
3. Tap **ENABLE ACCESSIBILITY SERVICE** and enable Super Sausage Auto.
4. Open the app again and tap **START RADIATED ELITE AUTO**.
5. Keep Z Route in its normal portrait orientation.
6. Tap **STOP / EMERGENCY STOP** at any time to halt the automation.

## Important

The automation is deliberately conservative. Z Route is a live game UI and can change between versions, languages, devices and events. If the expected labels are not recognised, the service does nothing rather than guessing. The Radiated Elite state machine may therefore need tuning against the exact current UI.

The app does not include purchase automation and will stop when purchase/payment indicators are detected.
