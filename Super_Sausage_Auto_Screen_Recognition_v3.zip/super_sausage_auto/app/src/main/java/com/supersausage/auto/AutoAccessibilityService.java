package com.supersausage.auto;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Super Sausage Auto v2.
 *
 * Mission-specific automation is intentionally conservative: it recognises
 * visible text first, taps only known mission controls, and stops on unknown
 * screens rather than guessing.
 */
public class AutoAccessibilityService extends AccessibilityService {
    private static AutoAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean running = new AtomicBoolean(false);
    private TextRecognizer recognizer;
    private long lastActionAt = 0L;
    private int cycles = 0;
    private int state = 0;
    private static final int MAX_CYCLES = 25;
    private static final long MIN_ACTION_GAP_MS = 1800L;

    private static final List<String> DANGEROUS = Arrays.asList(
            "buy", "purchase", "recharge", "pay", "payment", "pack", "bundle",
            "subscribe", "vip", "£", "$", "€", "diamond purchase", "confirm purchase"
    );

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // Screenshot/OCR loop is used because game controls may be rendered by Unity
        // and therefore may not expose useful AccessibilityNodeInfo text.
    }

    @Override public void onInterrupt() { stop(); }

    @Override public void onDestroy() {
        stop();
        if (recognizer != null) recognizer.close();
        instance = null;
        super.onDestroy();
    }

    public static void startAutomation() { if (instance != null) instance.start(); }
    public static void stopAutomation() { if (instance != null) instance.stop(); }

    private void start() {
        if (running.getAndSet(true)) return;
        cycles = 0;
        state = 0;
        try {
            android.content.Intent i = getPackageManager().getLaunchIntentForPackage("com.zroute.global");
            if (i != null) {
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        } catch (Exception ignored) { }
        handler.postDelayed(this::captureAndRecognise, 3000L);
    }

    private void stop() {
        running.set(false);
        handler.removeCallbacksAndMessages(null);
    }

    private void captureAndRecognise() {
        if (!running.get()) return;
        if (cycles >= MAX_CYCLES) { stop(); return; }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            // Visual recognition requires Android 11+ screenshot APIs.
            stop();
            return;
        }

        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    Bitmap bitmap = null;
                    try {
                        android.hardware.HardwareBuffer buffer = result.getHardwareBuffer();
                        if (buffer != null) {
                            bitmap = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
                            if (bitmap != null) bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false);
                            buffer.close();
                        }
                    } catch (Exception ignored) { }
                    if (bitmap == null) {
                        scheduleNext();
                        return;
                    }
                    final Bitmap image = bitmap;
                    recognizer.process(InputImage.fromBitmap(image, 0))
                            .addOnSuccessListener(text -> handleText(text, image))
                            .addOnFailureListener(e -> scheduleNext());
                }

                @Override public void onFailure(int errorCode) { scheduleNext(); }
            });
        } catch (Exception e) {
            scheduleNext();
        }
    }

    private void handleText(Text text, Bitmap bitmap) {
        if (!running.get()) return;
        String all = text.getText() == null ? "" : text.getText().toLowerCase(Locale.UK);

        // Never act if a purchase/payment screen is visible.
        for (String bad : DANGEROUS) {
            if (all.contains(bad)) {
                stop();
                return;
            }
        }

        // State 0: locate/open the Search or Zombie Elite screen.
        if (containsAny(all, "search", "zombie elite horde", "elite horde")) {
            if (state <= 1 && tapRecognised(text, "search", "zombie elite horde", "elite horde")) {
                state = 2;
                cycles = Math.max(cycles, 0);
                scheduleNext();
                return;
            }
        }

        // State 2: choose Radiated Elite.
        if (containsAny(all, "radiated elite", "radiated")) {
            if (state <= 3 && tapRecognised(text, "radiated elite", "radiated")) {
                state = 4;
                scheduleNext();
                return;
            }
        }

        // State 4: after target selection, use Team Up/Attack/March if present.
        if (containsAny(all, "team up", "team-up", "attack", "march", "start")) {
            if (state >= 4 && tapRecognised(text, "team up", "team-up", "attack", "march", "start")) {
                state = 5;
                scheduleNext();
                return;
            }
        }

        // If a result/claim/close control is visible, use it only after a mission action.
        if (state == 5 && containsAny(all, "claim", "close", "complete", "finished", "victory")) {
            if (tapRecognised(text, "claim", "close", "complete", "finished", "victory")) {
                cycles++;
                state = 0;
                scheduleNext();
                return;
            }
        }

        // On the world-map state, allow Search to begin the next cycle.
        if (state == 0 && containsAny(all, "world", "map", "search")) {
            if (tapRecognised(text, "search")) {
                state = 2;
                scheduleNext();
                return;
            }
        }

        // Unknown or ambiguous screen: do not tap. This is intentional.
        scheduleNext();
    }

    private boolean containsAny(String haystack, String... needles) {
        for (String n : needles) if (haystack.contains(n)) return true;
        return false;
    }

    /** Find an OCR text element matching a safe label and tap its centre. */
    private boolean tapRecognised(Text text, String... labels) {
        long now = System.currentTimeMillis();
        if (now - lastActionAt < MIN_ACTION_GAP_MS) return false;

        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String lineText = line.getText() == null ? "" : line.getText().toLowerCase(Locale.UK).trim();
                if (lineText.isEmpty()) continue;
                for (String label : labels) {
                    if (lineText.contains(label.toLowerCase(Locale.UK))) {
                        Rect r = line.getBoundingBox();
                        if (r != null && isSafeRegion(r)) {
                            tap(r.centerX(), r.centerY(), 80);
                            lastActionAt = now;
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private boolean isSafeRegion(Rect r) {
        // Avoid status bar and extreme screen edges where system controls often live.
        return r.centerY() > 80 && r.centerY() < getResources().getDisplayMetrics().heightPixels - 40;
    }

    private void tap(float x, float y, long durationMs) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, durationMs);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private void scheduleNext() {
        if (running.get()) handler.postDelayed(this::captureAndRecognise, 2200L);
    }
}
