package com.supersausage.auto;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32,40,32,32);

        TextView title = new TextView(this);
        title.setText("SUPER SAUSAGE AUTO");
        title.setTextSize(28);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1,80));

        TextView sub = new TextView(this);
        sub.setText("Z Route: Redemption\nRadiated Elite mission automation — v2.0");
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1,90));

        Button settings = new Button(this);
        settings.setText("1. ENABLE ACCESSIBILITY SERVICE");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(settings, new LinearLayout.LayoutParams(-1,70));

        Button start = new Button(this);
        start.setText("2. START RADIATED ELITE AUTO");
        start.setOnClickListener(v -> AutoAccessibilityService.startAutomation());
        root.addView(start, new LinearLayout.LayoutParams(-1,70));

        Button stop = new Button(this);
        stop.setText("STOP / EMERGENCY STOP");
        stop.setOnClickListener(v -> AutoAccessibilityService.stopAutomation());
        root.addView(stop, new LinearLayout.LayoutParams(-1,70));

        TextView note = new TextView(this);
        note.setPadding(0,30,0,0);
        note.setText("How it works:\n• Uses Android AccessibilityService + screenshot OCR.\n• Recognises mission labels instead of relying solely on fixed coordinates.\n• Stops if a purchase/payment screen is detected or the screen is ambiguous.\n• Maximum 25 mission cycles per run.\n\nAndroid 11+ is required for visual screen recognition.");
        root.addView(note, new LinearLayout.LayoutParams(-1,-2));

        setContentView(root);
    }
}
